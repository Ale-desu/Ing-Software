/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package tarea1.factory;

/**
 *
 * @author IIAN
 */
public interface Tienda {

    public static final int PC_HP = 1;
    public static final int PC_Alienware = 2;
    public static final int CEL_Xiaomi = 3;
    public static final int CEL_ZTE = 4;
    public static final int T_Apple = 5;
    public static final int T_Samsung = 6;
}
